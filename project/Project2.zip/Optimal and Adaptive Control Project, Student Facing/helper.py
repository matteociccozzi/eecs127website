import numpy as np

def simulate_system(y, u, which_system):
    if which_system == 1:
        A = np.array([[1, 1], [0, 1]])
        B = np.array([[1],[0]])
    elif which_system == 2:
        A = np.array([[0, 1], [0, 0]])
        B = np.array([[0],[1]])
    elif which_system == 3:
        A = np.array([[1, 1], [0, 1.99]])
        B = np.array([[1],[1]])
        
    else:
        raise NotImplementedError
    
    return A @ y + B @ u
